
To use the WeatherApp:
Unzip folder, keep ALL of the files in the same folder.
Run the setup.py application
Ready to use!!